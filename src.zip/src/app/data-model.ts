/**
 * New typescript file
 */
export class Book{
  id:number;
  title:string;
  coauthors:Author[];
}

export class Author{
  fname:string;
  lname:string;
}

//export const authors =[{fname:'f1',lname:'l1'},{fname:'f2',lname:'l2'},{fname:'f3',lname:'l3'},{fname:'f4',lname:'l1'}]
export const books=[{id:1,title:'t1',coauthors:[{fname:'f1',lname:'l1'},{fname:'f2',lname:'l2'}]},{id:2,title:'t2',coauthors:[{fname:'f3',lname:'l3'},{fname:'f4',lname:'l1'}]}];