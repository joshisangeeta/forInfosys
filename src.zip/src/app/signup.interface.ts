export interface User  {
  
}